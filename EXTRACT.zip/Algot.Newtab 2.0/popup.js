document.getElementById('saveBtn').addEventListener('click', function() {
    const url = document.getElementById('urlInput').value;
    chrome.storage.sync.set({ customNewTabUrl: url }, function() {
      alert('Custom URL saved!');
    });
  });
  