chrome.storage.sync.get(['customNewTabUrl'], function(result) {
  const url = result.customNewTabUrl ? `https://${result.customNewTabUrl}` : 'https://algot.fun/newtab'; // Default URL
  window.location.replace(url);
});
