let currentHotkey = ["Space"];
let extensionContextInvalidated = false;

chrome.storage.local.get("hotkey", (result) => {
  if (result.hotkey) currentHotkey = result.hotkey;
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.hotkey) {
    currentHotkey = changes.hotkey.newValue || ["Space"];
  }
});

function getPressedKeys(event) {
  const pressedKeys = new Set();

  if (event.ctrlKey) pressedKeys.add("Ctrl");
  if (event.altKey) pressedKeys.add("Alt");
  if (event.shiftKey) pressedKeys.add("Shift");
  if (event.metaKey) pressedKeys.add("Meta");

  const currentKey = event.key === " "
    ? "Space"
    : event.key.length === 1
      ? event.key.toUpperCase()
      : event.key;

  if (!["Control", "Alt", "Shift", "Meta"].includes(event.key)) {
    pressedKeys.add(currentKey);
  }

  return pressedKeys;
}

function handleContextInvalidated() {
  extensionContextInvalidated = true;
  window.removeEventListener("keydown", handleKeydown);
}

function handleKeydown(event) {
  if (extensionContextInvalidated) return;
  if (event.repeat) return;

  const activeElement = document.activeElement;
  const isInputField = activeElement && (
    activeElement.tagName === "INPUT" ||
    activeElement.tagName === "TEXTAREA" ||
    activeElement.isContentEditable
  );
  if (isInputField) return;

  const pressedKeys = getPressedKeys(event);
  const targetKeys = new Set(currentHotkey);
  const isMatch = targetKeys.size === pressedKeys.size
    && [...targetKeys].every((key) => pressedKeys.has(key));

  if (isMatch) {
    event.preventDefault();
    try {
      chrome.runtime.sendMessage({ type: "toggle-audio" }).catch(handleContextInvalidated);
    } catch (error) {
      handleContextInvalidated();
    }
  }
}

window.addEventListener("keydown", handleKeydown);