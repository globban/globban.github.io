let audioCtx = null;
let oscillator = null;
let gainNode = null;

function initAudio() {
  if (audioCtx) return;

  audioCtx = new AudioContext();
  gainNode = audioCtx.createGain();
  gainNode.gain.setValueAtTime(0.001, audioCtx.currentTime);
  gainNode.connect(audioCtx.destination);
}

function startAudio(frequency, waveform) {
  initAudio();
  if (audioCtx.state === "suspended") audioCtx.resume();

  if (oscillator) {
    oscillator.stop();
    oscillator.disconnect();
  }

  oscillator = audioCtx.createOscillator();
  oscillator.type = waveform;
  const maxFrequency = audioCtx.sampleRate / 2;
  oscillator.frequency.setValueAtTime(
    Math.min(Number(frequency), maxFrequency),
    audioCtx.currentTime
  );
  oscillator.connect(gainNode);
  oscillator.start();

  gainNode.gain.cancelScheduledValues(audioCtx.currentTime);
  gainNode.gain.setValueAtTime(gainNode.gain.value, audioCtx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.15, audioCtx.currentTime + 0.05);
}

function stopAudio() {
  if (!oscillator || !audioCtx) return;

  gainNode.gain.cancelScheduledValues(audioCtx.currentTime);
  gainNode.gain.setValueAtTime(gainNode.gain.value, audioCtx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.05);

  const oscillatorToStop = oscillator;
  oscillator = null;
  setTimeout(() => {
    oscillatorToStop.stop();
    oscillatorToStop.disconnect();
  }, 60);
}

function updateAudioParams(frequency, waveform) {
  if (!oscillator || !audioCtx) return;

  const maxFrequency = audioCtx.sampleRate / 2;
  oscillator.frequency.setValueAtTime(
    Math.min(Number(frequency), maxFrequency),
    audioCtx.currentTime
  );
  oscillator.type = waveform;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return;

  if (message.action === "startAudio") {
    startAudio(message.frequency, message.waveform);
  } else if (message.action === "stopAudio") {
    stopAudio();
  } else if (message.action === "updateAudioParams") {
    updateAudioParams(message.frequency, message.waveform);
  } else {
    return;
  }

  sendResponse({ ok: true });
});