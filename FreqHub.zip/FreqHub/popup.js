let audioCtx = null;
let oscillator = null;
let gainNode = null;

let isPlaying = false;
let currentHotkey = ["Space"];
let isRecordingHotkey = false;

// DOM Elements
const freqSlider = document.getElementById("freqSlider");
const freqInput = document.getElementById("freqInput");
const waveSelect = document.getElementById("waveSelect");
const toggleBtn = document.getElementById("toggleBtn");
const statusBadge = document.getElementById("statusBadge");
const recordHotkeyBtn = document.getElementById("recordHotkeyBtn");
const resetHotkeyBtn = document.getElementById("resetHotkeyBtn");

// Initialize State
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["frequency", "waveform", "hotkey", "isPlaying"], (result) => {
    if (result.frequency !== undefined) {
      updateFrequencyUI(result.frequency);
    }
    if (result.waveform) {
      waveSelect.value = result.waveform;
    }
    if (result.hotkey) {
      currentHotkey = result.hotkey;
    }
    updateHotkeyUI();
    updateStateUI(Boolean(result.isPlaying));
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.isPlaying) {
      updateStateUI(changes.isPlaying.newValue);
    }
  });
});

// Audio Controller
function initAudio() {
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  gainNode = audioCtx.createGain();
  gainNode.gain.setValueAtTime(0.001, audioCtx.currentTime); // Prevent click/pop
  gainNode.connect(audioCtx.destination);
}

function startAudio() {
  if (!audioCtx) initAudio();
  if (audioCtx.state === "suspended") audioCtx.resume();

  oscillator = audioCtx.createOscillator();
  oscillator.type = waveSelect.value;
  oscillator.frequency.setValueAtTime(parseFloat(freqSlider.value), audioCtx.currentTime);

  oscillator.connect(gainNode);
  oscillator.start();

  // Smooth ramp up
  gainNode.gain.cancelScheduledValues(audioCtx.currentTime);
  gainNode.gain.setValueAtTime(gainNode.gain.value, audioCtx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.15, audioCtx.currentTime + 0.05);

  isPlaying = true;
  updateStateUI();
}

function stopAudio() {
  if (!oscillator || !audioCtx) return;

  // Smooth ramp down to zero to prevent pop sound
  gainNode.gain.cancelScheduledValues(audioCtx.currentTime);
  gainNode.gain.setValueAtTime(gainNode.gain.value, audioCtx.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.05);

  setTimeout(() => {
    if (oscillator) {
      oscillator.stop();
      oscillator.disconnect();
      oscillator = null;
    }
  }, 50);

  isPlaying = false;
  updateStateUI();
}

function toggleAudio() {
  chrome.runtime.sendMessage({ type: "toggle-audio" });
}

// Frequency Controls
function updateFrequencyUI(value) {
  const val = Math.min(Math.max(value, 0), 30000);
  freqSlider.value = val;
  freqInput.value = val;

  if (oscillator && audioCtx) {
    const maxFrequency = audioCtx.sampleRate / 2;
    oscillator.frequency.setValueAtTime(Math.min(val, maxFrequency), audioCtx.currentTime);
  }

  chrome.storage.local.set({ frequency: val });
  chrome.runtime.sendMessage({
    type: "update-audio-params",
    frequency: val,
    waveform: waveSelect.value
  });
}

freqSlider.addEventListener("input", (e) => updateFrequencyUI(e.target.value));
freqInput.addEventListener("input", (e) => updateFrequencyUI(e.target.value));

waveSelect.addEventListener("change", (e) => {
  if (oscillator) oscillator.type = e.target.value;
  chrome.storage.local.set({ waveform: e.target.value });
  chrome.runtime.sendMessage({
    type: "update-audio-params",
    frequency: freqSlider.value,
    waveform: e.target.value
  });
});

toggleBtn.addEventListener("click", toggleAudio);

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "audio-state") {
    isPlaying = message.isPlaying;
    updateStateUI();
  }
});

function updateStateUI() {
  if (isPlaying) {
    toggleBtn.textContent = "Stop Tone";
    toggleBtn.className = "primary-btn active";
  } else {
    toggleBtn.textContent = "Start Tone";
    toggleBtn.className = "primary-btn";
  }
}

// Hotkey Recording & Detection
function updateHotkeyUI() {
  recordHotkeyBtn.textContent = currentHotkey.join(" + ");
}

recordHotkeyBtn.addEventListener("click", () => {
  isRecordingHotkey = true;
  recordHotkeyBtn.textContent = "Press keys now...";
  recordHotkeyBtn.classList.add("recording");
});

resetHotkeyBtn.addEventListener("click", () => {
  currentHotkey = ["Space"];
  chrome.storage.local.set({ hotkey: currentHotkey });
  updateHotkeyUI();
});

window.addEventListener("keydown", (e) => {
  // If typing inside frequency input, bypass hotkey listener
  if (document.activeElement === freqInput && !isRecordingHotkey) return;

  if (isRecordingHotkey) {
    e.preventDefault();
    const keys = [];
    if (e.ctrlKey) keys.push("Ctrl");
    if (e.altKey) keys.push("Alt");
    if (e.shiftKey) keys.push("Shift");
    if (e.metaKey) keys.push("Meta");

    const mainKey = e.key === " " ? "Space" : e.key;
    if (!["Control", "Alt", "Shift", "Meta"].includes(e.key)) {
      keys.push(mainKey.length === 1 ? mainKey.toUpperCase() : mainKey);
      currentHotkey = keys;
      isRecordingHotkey = false;
      recordHotkeyBtn.classList.remove("recording");
      updateHotkeyUI();
      chrome.storage.local.set({ hotkey: currentHotkey });
    } else {
      recordHotkeyBtn.textContent = keys.join(" + ") + "...";
    }
    return;
  }

  // Hotkey Matching
  const targetKeys = new Set(currentHotkey);
  const pressedKeys = new Set();

  if (e.ctrlKey) pressedKeys.add("Ctrl");
  if (e.altKey) pressedKeys.add("Alt");
  if (e.shiftKey) pressedKeys.add("Shift");
  if (e.metaKey) pressedKeys.add("Meta");

  const currentKey = e.key === " " ? "Space" : (e.key.length === 1 ? e.key.toUpperCase() : e.key);
  if (!["Control", "Alt", "Shift", "Meta"].includes(e.key)) {
    pressedKeys.add(currentKey);
  }

  const isMatch = targetKeys.size === pressedKeys.size && [...targetKeys].every(k => pressedKeys.has(k));
  if (isMatch) {
    e.preventDefault();
    toggleAudio();
  }
});