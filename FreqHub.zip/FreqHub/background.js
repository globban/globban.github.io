let creatingOffscreen = null;

async function ensureOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"]
  });
  if (contexts.length > 0) return;

  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Play the configured frequency while the popup is closed."
    });
  }

  try {
    await creatingOffscreen;
  } finally {
    creatingOffscreen = null;
  }
}

async function closeOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"]
  });
  if (contexts.length > 0) await chrome.offscreen.closeDocument();
}

async function sendToOffscreen(message) {
  await ensureOffscreenDocument();
  return chrome.runtime.sendMessage(message);
}

async function handleToggleAudio() {
  const settings = await chrome.storage.local.get({
    isPlaying: false,
    frequency: 440,
    waveform: "sine"
  });
  const isPlaying = !settings.isPlaying;

  await chrome.storage.local.set({ isPlaying });
  if (isPlaying) {
    await sendToOffscreen({
      action: "startAudio",
      frequency: settings.frequency,
      waveform: settings.waveform
    });
  } else {
    await sendToOffscreen({ action: "stopAudio" });
    setTimeout(() => closeOffscreenDocument().catch(console.error), 100);
  }

  return { isPlaying };
}

async function handleUpdateParams(frequency, waveform) {
  await chrome.storage.local.set({ frequency, waveform });
  const { isPlaying = false } = await chrome.storage.local.get("isPlaying");
  if (isPlaying) {
    await sendToOffscreen({ action: "updateAudioParams", frequency, waveform });
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle-audio") handleToggleAudio().catch(console.error);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return;

  if (message.type === "toggle-audio" || message.action === "toggleAudio") {
    handleToggleAudio()
      .then(sendResponse)
      .catch((error) => sendResponse({ error: error.message }));
    return true;
  }

  if (message.type === "update-audio-params" || message.action === "updateAudioParams") {
    handleUpdateParams(message.frequency, message.waveform)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ error: error.message }));
    return true;
  }
});