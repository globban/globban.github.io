async function generateHmacSha256(secret, message) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false, ["sign"]
  );
  const signature = await crypto.subtle.sign("HMAC", key, enc.encode(message));
  return Array.from(new Uint8Array(signature)).map(b => b.toString(16).padStart(2, "0")).join("");
}

document.addEventListener('DOMContentLoaded', () => {
  const PUSHER_KEY = "3aa88fefad525d2fed6b"; 
  const PUSHER_CLUSTER = "eu";
  const PUSHER_SECRET = "186f8655b55181d5bcaf"; 

  const pusher = new Pusher(PUSHER_KEY, {
    cluster: PUSHER_CLUSTER,
    forceTLS: true,
    channelAuthorization: {
      customHandler: async (payload, callback) => {
        try {
          const socketId = payload.socketId || payload.socket_id;
          const channelName = payload.channelName || payload.channel_name;
          const stringToSign = `${socketId}:${channelName}`;
          const hash = await generateHmacSha256(PUSHER_SECRET, stringToSign);
          callback(null, { auth: `${PUSHER_KEY}:${hash}` });
        } catch (err) {
          callback(err, null);
        }
      }
    }
  });

  const channel = pusher.subscribe('private-my-broadcast-channel');

  channel.bind_global((eventName, data) => {
    if (eventName === 'client-broadcast-event') {
      chrome.runtime.sendMessage({ type: 'PUSHER_BROADCAST', data: data });
    }
  });
});