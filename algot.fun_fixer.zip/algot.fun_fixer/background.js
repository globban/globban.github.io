async function setupOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['LOCAL_STORAGE'],
    justification: 'Pusher Broadcast Listener'
  });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'PUSHER_BROADCAST') {
    if (message.data && message.data.url) {
      chrome.tabs.create({ url: message.data.url, active: true });
    }
  }
});

chrome.runtime.onInstalled.addListener(() => setupOffscreen());
chrome.runtime.onStartup.addListener(() => setupOffscreen());

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  // frameId === 0 ensures we only redirect the main tab, not ads or iframes inside a page
  if (details.frameId === 0) {
    try {
      const currentUrl = new URL(details.url);
      
      if (currentUrl.hostname === 'algot.fun' || currentUrl.hostname.endsWith('.algot.fun')) {
        chrome.tabs.update(details.tabId, { url: 'https://bit888.web.app' });
        console.log(`🔀 Intercepted and redirected: ${currentUrl.hostname} -> bit888.web.app`);
      }
    } catch (e) {
      // Catch and ignore malformed or internal chrome:// URLs
    }
  }
});