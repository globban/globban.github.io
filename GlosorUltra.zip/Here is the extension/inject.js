// inject.js
(function() {
    // 1. Fake the visibility API
    Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
    Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });

    // 2. Block the specific events Glosor listens for
    const block = (e) => {
        e.stopImmediatePropagation();
    };
    window.addEventListener('blur', block, true);
    window.addEventListener('mouseleave', block, true);
    
    // 3. Fake the focus state globally
    Object.defineProperty(document, 'hasFocus', { value: () => true });

    // 4. Wipe the site's internal blur variable
    window.otBlur = () => false;
    
    console.log("Deep Shield Active: Stealth Mode Engaged via External Script.");
})();