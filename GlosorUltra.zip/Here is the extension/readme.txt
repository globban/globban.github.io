    :::     :::         ::::::::   ::::::::  :::::::::::     :::::::::: :::    ::: ::::    :::
  :+: :+:   :+:        :+:    :+: :+:    :+:     :+:         :+:        :+:    :+: :+:+:   :+:
 +:+   +:+  +:+        +:+        +:+    +:+     +:+         +:+        +:+    +:+ :+:+:+  +:+
+ ++:++ ++: + +        : :        + +    +:+     + +         : ::+::    + +    +:+ + + +:+ + +
+ +     + + + +        + +   + +  + +    + +     + +         + +        + +    + + + +  + + +
 +       +   +          +      +   +      +       +       +   +          +      +   +     + +


This is a Vibe-coded project to cheat in glosor.eu

--FOR EDUCATIONAL PURPOSES ONLY--

It is a bad idea to use this, and I am not responsible for any consequences that may arise from using it. Use at your own risk.
Your grades may lower.

This project is free-use, but I would appreciate it if you give me credit if you use it or parts of it in your own project. 
Publishing this project commercially would be a bad idea but if you do, DO NOT GIVE ME CREDIT. I do not want to be associated with any commercial use of this project.

Originally created by:
    Algot
Originally published on:
    https://www.algot.fun
    https://globban.github.io

This pjoject was a pleasure to create and i hope it can be useful to someone, but I do not recommend using it. It is a fun project to create, but it is not a good idea to use it. UNDERSTOOD? GOOD. HAVE A NICE DAY.