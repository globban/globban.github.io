const toggles = ['scrape-toggle', 'type-toggle', 'anti-toggle'];

// Initialization
chrome.storage.local.get([...toggles, 'vocabDict'], (data) => {
  toggles.forEach(id => {
    document.getElementById(id).checked = data[id] !== false;
  });
  displayWords(data.vocabDict || {});
});

// Toggle listeners
toggles.forEach(id => {
  document.getElementById(id).addEventListener('change', (e) => {
    chrome.storage.local.set({ [id]: e.target.checked });
  });
});

// Search
document.getElementById('search').addEventListener('input', (e) => {
  const term = e.target.value.toLowerCase();
  chrome.storage.local.get(['vocabDict'], (data) => {
    const filtered = {};
    Object.entries(data.vocabDict || {}).forEach(([k, v]) => {
      if (k.toLowerCase().includes(term) || v.toLowerCase().includes(term)) filtered[k] = v;
    });
    displayWords(filtered);
  });
});

// --- CLEAR ALL WORDS ---
document.getElementById('clear-all').addEventListener('click', () => {
  if (confirm("Are you sure you want to delete all saved words?")) {
    chrome.storage.local.set({ vocabDict: {} }, () => {
      displayWords({});
      // Optional: Force a refresh alert to content script
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, {action: "clear_memory"});
      });
    });
  }
});

function displayWords(dict) {
  const container = document.getElementById('word-container');
  container.innerHTML = '';
  const entries = Object.entries(dict);
  if (entries.length === 0) {
    container.innerHTML = '<div style="padding:20px;text-align:center;color:#8e8e93">No words saved</div>';
    return;
  }
  entries.forEach(([word, translation]) => {
    const div = document.createElement('div');
    div.className = 'word-pair';
    div.innerHTML = `<span>${word}</span><span style="color:#8e8e93">${translation}</span>`;
    container.appendChild(div);
  });
}