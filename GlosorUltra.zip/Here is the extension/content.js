// --- 1. DEEP SHIELD INJECTION (Respects Toggle) ---
function applyShield() {
    chrome.storage.local.get(['anti-toggle'], (data) => {
        if (data['anti-toggle'] === false) {
            console.log("Glosor Ultra: Anti-Detection is OFF.");
            return;
        }

        const script = document.createElement('script');
        script.src = chrome.runtime.getURL('inject.js');
        script.onload = function() { this.remove(); };
        (document.head || document.documentElement).appendChild(script);
    });
}

// --- 2. TYPEWRITER ENGINE ---
async function typeAnswer(inputField, text) {
    if (inputField.dataset.isTyping === "true") return;
    inputField.dataset.isTyping = "true";
    
    inputField.focus();
    inputField.value = "";

    for (let i = 0; i < text.length; i++) {
        inputField.value += text.charAt(i);
        const opts = { bubbles: true, key: text.charAt(i) };
        inputField.dispatchEvent(new InputEvent('input', opts));
        inputField.dispatchEvent(new KeyboardEvent('keydown', opts));
        inputField.dispatchEvent(new KeyboardEvent('keyup', opts));
        await new Promise(r => setTimeout(r, 60 + Math.random() * 90));
    }

    inputField.dispatchEvent(new Event('change', { bubbles: true }));
    inputField.dataset.isTyping = "false";
}

// --- 3. THE SOLVER (Respects Toggle) ---
function solveQuestion() {
    if (!chrome.runtime?.id) return;

    chrome.storage.local.get(['type-toggle', 'vocabDict'], (data) => {
        if (data['type-toggle'] === false) return;

        try {
            const inputField = document.getElementById('otFormInput') || 
                              document.getElementById('focusFirst') || 
                              document.querySelector('input[type="text"]:not([style*="display: none"])');

            const questionEl = document.querySelector('.well.question') || 
                              document.querySelector('#otForm .form-control[style*="height:auto"]') || 
                              document.querySelector('#exerc-question .form-control');

            if (inputField && questionEl && inputField.dataset.isTyping !== "true" && inputField.value === "") {
                const currentQuestion = questionEl.innerText.trim();
                const dict = data.vocabDict || {};
                
                let answer = dict[currentQuestion];
                if (!answer) {
                    const searchKey = currentQuestion.toLowerCase();
                    const foundKey = Object.keys(dict).find(k => k.toLowerCase() === searchKey);
                    if (foundKey) answer = dict[foundKey];
                }

                if (answer) {
                    typeAnswer(inputField, answer);
                }
            }
        } catch (e) {}
    });
}

// --- 4. THE SCANNER (Respects Toggle) ---
function scanVocabulary() {
    if (!chrome.runtime?.id) return;

    chrome.storage.local.get(['scrape-toggle', 'vocabDict'], (data) => {
        if (data['scrape-toggle'] === false) return;

        const items = document.querySelectorAll('.list-group-item, tr[id^="q_"], .exl-row');
        if (items.length === 0) return;

        let dictionary = data.vocabDict || {};
        let newFound = false;

        items.forEach(item => {
            const cols = item.querySelectorAll('.exl-c2, td, .exl-col');
            if (cols.length >= 2) {
                const w1 = cols[0].innerText.trim();
                const w2 = cols[1].innerText.trim();
                if (w1 && w2 && !w1.includes('Svenska')) {
                    if (dictionary[w1] !== w2) {
                        dictionary[w1] = w2;
                        dictionary[w2] = w1;
                        newFound = true;
                    }
                }
            }
        });
        
        if (newFound) {
            chrome.storage.local.set({ vocabDict: dictionary }, () => {
                console.log("Memory Updated. Total words: " + Object.keys(dictionary).length);
            });
        }
    });
}

// --- 5. INITIALIZATION ---
function init() {
    if (!document.body) {
        setTimeout(init, 50);
        return;
    }

    applyShield();
    scanVocabulary();

    const observer = new MutationObserver(() => {
        solveQuestion();
        scanVocabulary(); // Keep scanning in case more words load
    });

    observer.observe(document.body, { childList: true, subtree: true });
}

// Listen for the "Clear All" signal from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "clear_memory") {
        console.log("Glosor Ultra: Memory cleared by user.");
        // This forces the script to stop trying to type until it scans again
        location.reload(); 
    }
});

init();