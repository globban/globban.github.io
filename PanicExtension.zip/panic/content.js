let config = {
  goodUrl: "https://google.com",
  goodTitle: "Google",
  goodFavicon: "https://www.google.com/favicon.ico",
  badUrls: [],
  panicCombo: ["ShiftLeft", "ShiftRight"],
  panicOnBlur: false
};

const pressedCodes = new Set();
let cloakObserver = null;

function normalizeUrl(url) {
  return url ? url.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '') : '';
}

function isBadBoySite() {
  const current = normalizeUrl(window.location.href);
  return config.badUrls.some(bad => {
    const cleanBad = normalizeUrl(bad);
    return cleanBad && current.includes(cleanBad);
  });
}

function applyTabCloak() {
  if (!isBadBoySite()) return;

  // 1. Force Title
  if (config.goodTitle && document.title !== config.goodTitle) {
    document.title = config.goodTitle;
  }

  // 2. Force Favicon
  if (config.goodFavicon) {
    let icon = document.querySelector("link[rel*='icon']") || document.createElement('link');
    icon.type = 'image/x-icon';
    icon.rel = 'shortcut icon';
    icon.href = config.goodFavicon;
    if (!icon.parentNode) {
      (document.head || document.documentElement).appendChild(icon);
    }
  }
}

function startPersistentCloak() {
  if (!isBadBoySite()) return;

  applyTabCloak();

  // Observer to override dynamic scripts trying to change title/favicon
  if (!cloakObserver) {
    cloakObserver = new MutationObserver(() => applyTabCloak());
    cloakObserver.observe(document.head || document.documentElement, {
      subtree: true,
      childList: true,
      characterData: true
    });
  }

  // Backup interval checker
  setInterval(applyTabCloak, 1000);
}

// Load initial config
chrome.storage.sync.get(["goodUrl", "goodTitle", "goodFavicon", "badUrls", "panicCombo", "panicOnBlur"], (res) => {
  Object.assign(config, res);
  initCloakAndPanic();
});

// React live to settings changes in popup
chrome.storage.onChanged.addListener((changes) => {
  for (let key in changes) {
    config[key] = changes[key].newValue;
  }
  if (isBadBoySite()) {
    startPersistentCloak();
  }
});

function checkComboMatch() {
  if (!config.panicCombo || config.panicCombo.length === 0) return false;
  return config.panicCombo.every(code => pressedCodes.has(code));
}

function triggerLocalPanic() {
  // Directly bounce this page to safe site instantly
  window.location.href = config.goodUrl || "https://google.com";
}

function initCloakAndPanic() {
  if (isBadBoySite()) {
    startPersistentCloak();
  }

  // Multi-key physical combination detection
  window.addEventListener("keydown", (e) => {
    pressedCodes.add(e.code);
    if (checkComboMatch()) {
      triggerLocalPanic();
    }
  }, true);

  window.addEventListener("keyup", (e) => {
    pressedCodes.delete(e.code);
  }, true);

  // Auto-panic on Blur/Unfocus (Only triggers if currently on a Bad Boy site)
  window.addEventListener("blur", () => {
    pressedCodes.clear();
    if (config.panicOnBlur && isBadBoySite()) {
      // Send message with sender.tab.id to background to bounce THIS tab specifically
      chrome.runtime.sendMessage({ action: "panic" });
    }
  });
}