function formatUrl(url) {
  if (!url) return "https://google.com";
  return /^https?:\/\//i.test(url) ? url : "https://" + url;
}

// Automatically derive & sync title + favicon whenever goodUrl changes
function autoSyncMetadata(goodUrl) {
  try {
    const parsed = new URL(formatUrl(goodUrl));
    const host = parsed.hostname.replace("www.", "");
    const title = host.charAt(0).toUpperCase() + host.slice(1);
    const favicon = `https://www.google.com/s2/favicons?domain=${parsed.hostname}&sz=64`;

    chrome.storage.sync.set({ goodTitle: title, goodFavicon: favicon });
  } catch (e) {
    chrome.storage.sync.set({ goodTitle: "Google", goodFavicon: "https://www.google.com/favicon.ico" });
  }
}

// Trigger panic specifically for the tab that initiated it
function triggerPanic(targetTabId) {
  chrome.storage.sync.get(["goodUrl"], (result) => {
    const targetUrl = formatUrl(result.goodUrl || "https://google.com");

    if (targetTabId) {
      // Bounce the SPECIFIC tab that triggered blur or hotkey
      chrome.tabs.update(targetTabId, { url: targetUrl });
    } else {
      // Fallback: Bounce active tab (e.g. when clicking Panic button in popup)
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.update(tabs[0].id, { url: targetUrl });
        }
      });
    }
  });
}

// Sync metadata automatically when goodUrl changes
chrome.storage.onChanged.addListener((changes) => {
  if (changes.goodUrl && changes.goodUrl.newValue) {
    autoSyncMetadata(changes.goodUrl.newValue);
  }
});

// Message listener with sender tab identification
chrome.runtime.onMessage.addListener((request, sender) => {
  if (request.action === "panic") {
    const senderTabId = sender.tab ? sender.tab.id : null;
    triggerPanic(senderTabId);
  }
});