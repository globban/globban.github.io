const goodInput = document.getElementById("good-url");
const badUrlInput = document.getElementById("bad-url-input");
const badListEl = document.getElementById("bad-list");
const panicKeyDisplay = document.getElementById("panic-key-display");
const btnRecordKey = document.getElementById("btn-record-key");
const blurToggle = document.getElementById("blur-toggle");

let badUrls = [];
let isRecording = false;
let recordedCodes = new Set();

function formatUrl(url) {
  if (!url) return "";
  return /^https?:\/\//i.test(url) ? url : "https://" + url;
}

function formatCodeName(code) {
  const map = {
    ShiftLeft: "Left Shift",
    ShiftRight: "Right Shift",
    ControlLeft: "Left Ctrl",
    ControlRight: "Right Ctrl",
    AltLeft: "Left Alt",
    AltRight: "Right Alt"
  };
  if (map[code]) return map[code];
  return code.replace("Key", "").replace("Digit", "");
}

function renderComboDisplay(codesArray) {
  if (!codesArray || codesArray.length === 0) return "None";
  return codesArray.map(formatCodeName).join(" + ");
}

function renderBadList() {
  badListEl.innerHTML = "";
  badUrls.forEach((url, index) => {
    const li = document.createElement("li");
    li.className = "bad-item";
    li.innerHTML = `
      <span>${url}</span>
      <button data-index="${index}">×</button>
    `;
    badListEl.appendChild(li);
  });

  document.querySelectorAll(".bad-item button").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const idx = e.target.getAttribute("data-index");
      badUrls.splice(idx, 1);
      chrome.storage.sync.set({ badUrls });
      renderBadList();
    });
  });
}

// Initial Load
chrome.storage.sync.get(["goodUrl", "badUrls", "panicCombo", "panicOnBlur"], (res) => {
  if (res.goodUrl) goodInput.value = res.goodUrl;
  badUrls = res.badUrls || [];
  renderBadList();
  panicKeyDisplay.value = renderComboDisplay(res.panicCombo || ["ShiftLeft", "ShiftRight"]);
  blurToggle.checked = !!res.panicOnBlur;
});

// Auto-Sync Good URL on input change
goodInput.addEventListener("input", () => {
  const val = formatUrl(goodInput.value.trim());
  chrome.storage.sync.set({ goodUrl: val });
});

// Add Bad URL
document.getElementById("btn-add-bad").addEventListener("click", () => {
  const val = formatUrl(badUrlInput.value.trim());
  if (val && !badUrls.includes(val)) {
    badUrls.push(val);
    chrome.storage.sync.set({ badUrls });
    renderBadList();
    badUrlInput.value = "";
  }
});

// Add Current Tab to Bad List
document.getElementById("btn-add-current").addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].url) {
      const currentUrl = tabs[0].url;
      if (!badUrls.includes(currentUrl)) {
        badUrls.push(currentUrl);
        chrome.storage.sync.set({ badUrls });
        renderBadList();
      }
    }
  });
});

// Record Hotkey Combination
btnRecordKey.addEventListener("click", () => {
  isRecording = true;
  recordedCodes.clear();
  btnRecordKey.textContent = "Press keys...";
  btnRecordKey.classList.add("recording");
  panicKeyDisplay.value = "Listening...";
});

window.addEventListener("keydown", (e) => {
  if (!isRecording) return;
  e.preventDefault();
  e.stopPropagation();

  recordedCodes.add(e.code);
  panicKeyDisplay.value = renderComboDisplay(Array.from(recordedCodes));
});

window.addEventListener("keyup", (e) => {
  if (!isRecording) return;
  if (recordedCodes.size > 0) {
    const finalCombo = Array.from(recordedCodes);
    chrome.storage.sync.set({ panicCombo: finalCombo });

    isRecording = false;
    btnRecordKey.textContent = "Record";
    btnRecordKey.classList.remove("recording");
  }
});

// Unfocus/Blur Toggle
blurToggle.addEventListener("change", () => {
  chrome.storage.sync.set({ panicOnBlur: blurToggle.checked });
});

// Manual Panic Button
document.getElementById("btn-panic").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "panic" });
});