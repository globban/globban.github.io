async function setupOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['LOCAL_STORAGE'],
    justification: 'Pusher Mesh Link'
  });
}

//  THE CORRECT WAY (link-sender/background.js)
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'SEND_BROADCAST') {
    chrome.offscreen.hasDocument().then((exists) => {
      if (exists) {
        chrome.offscreen.closeDocument().then(() => createSenderOffscreen(message.url));
      } else {
        createSenderOffscreen(message.url);
      }
    });
  } else if (message.type === 'CLOSE_SENDER') {
    chrome.offscreen.closeDocument().catch(() => {});
  }
});

function createSenderOffscreen(targetUrl) {
  chrome.offscreen.createDocument({
    // Data is passed safely here through the window URL string instead!
    url: `offscreen.html?url=${encodeURIComponent(targetUrl)}`,
    reasons: ['LOCAL_STORAGE'],
    justification: 'Pusher Mesh Link Sender'
  }).catch((err) => console.error(err));
}
chrome.runtime.onInstalled.addListener(() => setupOffscreen());
chrome.runtime.onStartup.addListener(() => setupOffscreen());