document.getElementById('send-current').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url) {
    chrome.runtime.sendMessage({ type: 'SEND_BROADCAST', url: tab.url });
    window.close(); 
  }
});

document.getElementById('send-manual').addEventListener('click', () => {
  const urlInput = document.getElementById('manual-url').value;
  if (urlInput) {
    chrome.runtime.sendMessage({ type: 'SEND_BROADCAST', url: urlInput });
    window.close();
  }
});