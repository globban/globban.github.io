// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
  initializeBackground();
  initializeGoogleAppsMenu();
  initializeSettingsMenu();
  initializeQuickAccessLinks();
  initializeCustomApps();
  initializeVisibilityToggles();
  initializeResetButton();
  loadAllSettings();
  renderQuickAccessDisplay();
  renderQuickAccessLinks();
  restoreVisibilityToggles();
});

const defaultapps = [
  { url: "https://mail.google.com/", icon: "fas fa-envelope", name: "Gmail" },
  { url: "https://www.youtube.com/", icon: "fab fa-youtube", name: "YouTube" },
  { url: "https://drive.google.com/", icon: "fab fa-google-drive", name: "Drive" },
  { url: "https://www.google.com/maps", icon: "fas fa-map-marker-alt", name: "Maps" },
  { url: "https://docs.google.com/", icon: "fas fa-file-alt", name: "Docs" },
  { url: "https://classroom.google.com/", icon: "fas fa-chalkboard-teacher", name: "Classroom" },
  { url: "https://slides.google.com/", icon: "fas fa-file-powerpoint", name: "Slides" },
  { url: "https://algot.fun", icon: "fas fa-code", name: "Algot.fun" },
  { url: "https://chatgpt.com/", icon: "fas fa-comments", name: "ChatGPT" }
];


const weatherCityKey = document.getElementById('weatherCity') || 'Stockholm';

const DEFAULT_BACKGROUND_URL = 'https://images.unsplash.com/photo-1763411711221-40166c5e20cd?q=80&w=2093&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D.png';

// ==================== BACKGROUND IMAGE ====================
function initializeBackground() {
  const savedImage = localStorage.getItem('backgroundImage');
  if (savedImage) {
    document.body.style.backgroundImage = `url('${savedImage}')`;
  } else {
    document.body.style.backgroundImage = `url('${DEFAULT_BACKGROUND_URL}')`;
  }

  document.getElementById('customImageInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(event) {
        const imageUrl = event.target.result;
        document.body.style.backgroundImage = `url('${imageUrl}')`;
        localStorage.setItem('backgroundImage', imageUrl);
      };
      reader.readAsDataURL(file);
    }
  });

  document.getElementById('setUrlBtn').addEventListener('click', function() {
    const urlInput = document.getElementById('customImageUrlInput');
    const url = urlInput.value.trim();
    const errorSpan = document.getElementById('urlError');
    
    if (!url) {
      errorSpan.textContent = 'Please enter a URL';
      errorSpan.style.display = 'block';
      return;
    }

    // Test if the image loads
    const img = new Image();
    img.onload = function() {
      document.body.style.backgroundImage = `url('${url}')`;
      localStorage.setItem('backgroundImage', url);
      errorSpan.style.display = 'none';
      urlInput.value = '';
    };
    img.onerror = function() {
      errorSpan.textContent = 'Failed to load image. Check the URL.';
      errorSpan.style.display = 'block';
    };
    img.src = url;
  });
}

// ==================== GOOGLE APPS MENU ====================
function initializeGoogleAppsMenu() {
  const googleAppsBtn = document.getElementById('googleAppsBtn');
  const appsMenu = document.getElementById('appsMenu');

  googleAppsBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    appsMenu.style.display = appsMenu.style.display === 'none' ? 'block' : 'none';
  });

  document.addEventListener('click', function(e) {
    if (!googleAppsBtn.contains(e.target) && !appsMenu.contains(e.target)) {
      appsMenu.style.display = 'none';
    }
  });
  // Load default apps
  defaultapps.forEach(app => {
    
  });
}

// ==================== SETTINGS MENU ====================
function initializeSettingsMenu() {
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsMenu = document.getElementById('settingsMenu');
  const closeBtn = document.getElementById('closeSettingsMenu');

  settingsBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    settingsMenu.style.display = settingsMenu.style.display === 'block' ? 'none' : 'block';
  });

  closeBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    settingsMenu.style.display = 'none';
  });

  document.addEventListener('click', function(e) {
    if (!settingsBtn.contains(e.target) && !settingsMenu.contains(e.target)) {
      settingsMenu.style.display = 'none';
    }
  });
}

// ==================== QUICK ACCESS LINKS ====================
function initializeQuickAccessLinks() {
  document.getElementById('addQuickAccessBtn').addEventListener('click', addQuickAccessLink);
  document.getElementById('newLinkUrl').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      addQuickAccessLink();
    }
  });
}

function addQuickAccessLink() {
  const input = document.getElementById('newLinkUrl');
  const urlOrName = input.value.trim();
  const errorSpan = document.getElementById('linkError');

  if (!urlOrName) {
    errorSpan.textContent = 'Please enter a URL or name:url';
    errorSpan.style.display = 'block';
    return;
  }

  const { name, url } = parseInput(urlOrName);

  if (!isValidUrl(url)) {

    errorSpan.textContent = 'Invalid URL format';
    errorSpan.style.display = 'block';
    return;
  }

  let quickLinks = JSON.parse(localStorage.getItem('quickAccessLinks') || '[]');
  
  if (quickLinks.some(link => link.url === url)) {
    errorSpan.textContent = 'This link already exists';
    errorSpan.style.display = 'block';
    return;
  }

  quickLinks.push({ name, url });
  localStorage.setItem('quickAccessLinks', JSON.stringify(quickLinks));
  
  input.value = '';
  errorSpan.style.display = 'none';
  
  renderQuickAccessLinks();
  renderQuickAccessDisplay();
}

function removeQuickAccessLink(url) {
  let quickLinks = JSON.parse(localStorage.getItem('quickAccessLinks') || '[]');
  quickLinks = quickLinks.filter(link => link.url !== url);
  localStorage.setItem('quickAccessLinks', JSON.stringify(quickLinks));
  
  renderQuickAccessLinks();
  renderQuickAccessDisplay();
}

function renderQuickAccessLinks() {
  const list = document.getElementById('quickAccessList');
  const quickLinks = JSON.parse(localStorage.getItem('quickAccessLinks') || '[]');
  
  list.innerHTML = '';
  
  if (quickLinks.length === 0) {
    list.innerHTML = '<p style="font-size:0.9em;color:#999;">No quick access links yet</p>';
    return;
  }

  quickLinks.forEach(link => {
    const div = document.createElement('div');
    div.className = 'custom-link-item';
    
    const favicon = getFaviconUrl(link.url);
    const linkInfo = document.createElement('div');
    linkInfo.className = 'custom-link-item-info';
    linkInfo.innerHTML = `
      <img src="${favicon}" alt="" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22%3E%3Crect fill=%22%23ccc%22 width=%2216%22 height=%2216%22/%3E%3C/svg%3E'">
      <span>${link.name}</span>
    `;
    
    const removeBtn = document.createElement('button');
    removeBtn.textContent = 'Remove';
    removeBtn.addEventListener('click', () => removeQuickAccessLink(link.url));
    
    div.appendChild(linkInfo);
    div.appendChild(removeBtn);
    list.appendChild(div);
  });
}

function renderQuickAccessDisplay() {
  const container = document.getElementById('quickAccessContainer');
  const quickLinks = JSON.parse(localStorage.getItem('quickAccessLinks') || '[]');
  
  container.innerHTML = '';

  quickLinks.forEach(link => {
    const favicon = getFaviconUrl(link.url);
    const a = document.createElement('a');
    a.href = link.url;
    a.target = '_blank';
    a.className = 'quick-access-link';
    a.innerHTML = `
      <img src="${favicon}" alt="" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22%3E%3Crect fill=%22%23ccc%22 width=%2216%22 height=%2216%22/%3E%3C/svg%3E'">
      <span>${link.name}</span>
    `;
    container.appendChild(a);
  });
}

// ==================== CUSTOM APPS ====================
function initializeCustomApps() {
  document.getElementById('addCustomAppBtn').addEventListener('click', addCustomApp);
  document.getElementById('newAppUrl').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      addCustomApp();
    }
  });
}

function addCustomApp() {
  const input = document.getElementById('newAppUrl');
  const urlOrName = input.value.trim();

  if (!urlOrName) {
    alert('Please enter a URL or name:url');
    return;
  }

  const { name, url } = parseInput(urlOrName);

  if (!isValidUrl(url)) {
    alert('Invalid URL format');
    return;
  }

  let customApps = JSON.parse(localStorage.getItem('customApps') || '[]');
  
  if (customApps.some(app => app.url === url)) {
    alert('This app already exists');
    return;
  }

  customApps.push({ name, url });
  localStorage.setItem('customApps', JSON.stringify(customApps));
  
  input.value = '';
  
  renderCustomApps();
  updateAppsMenu();
}

function removeCustomApp(url) {
  let customApps = JSON.parse(localStorage.getItem('customApps') || '[]');
  customApps = customApps.filter(app => app.url !== url);
  localStorage.setItem('customApps', JSON.stringify(customApps));
  
  renderCustomApps();
  updateAppsMenu();
}

function renderCustomApps() {
  const list = document.getElementById('customAppsList');
  const customApps = JSON.parse(localStorage.getItem('customApps') || '[]');
  
  list.innerHTML = '';
  
  if (customApps.length === 0) {
    list.innerHTML = '<p style="font-size:0.9em;color:#999;">No custom apps yet</p>';
    return;
  }

  customApps.forEach(app => {
    const div = document.createElement('div');
    div.className = 'custom-link-item';
    
    const favicon = getFaviconUrl(app.url);
    const appInfo = document.createElement('div');
    appInfo.className = 'custom-link-item-info';
    appInfo.innerHTML = `
      <img src="${favicon}" alt="" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22%3E%3Crect fill=%22%23ccc%22 width=%2216%22 height=%2216%22/%3E%3C/svg%3E'">
      <span>${app.name}</span>
    `;
    
    const removeBtn = document.createElement('button');
    removeBtn.textContent = 'Remove';
    removeBtn.addEventListener('click', () => removeCustomApp(app.url));
    
    div.appendChild(appInfo);
    div.appendChild(removeBtn);
    list.appendChild(div);
  });
}

function updateAppsMenu() {
  const appsMenu = document.getElementById('appsMenu');
  const customApps = JSON.parse(localStorage.getItem('customApps') || '[]');
  const ul = appsMenu.querySelector('ul');
  
  // Remove old custom app items
  const customAppItems = ul.querySelectorAll('[data-custom="true"]');
  customAppItems.forEach(item => item.remove());
  
  // Add new custom apps
  customApps.forEach(app => {
    const li = document.createElement('li');
    li.setAttribute('data-custom', 'true');
    const favicon = getFaviconUrl(app.url);
    li.innerHTML = `
      <a href="${app.url}" target="_blank">
        <img src="${favicon}" alt="" style="width:16px;height:16px;border-radius:2px;margin-right:8px;" onerror="this.style.display='none'">
        <span>${app.name}</span>
      </a>
    `;
    ul.appendChild(li);
  });
}

// ==================== UTILITY FUNCTIONS ====================
function parseInput(input) {
  if (input.includes(':') && !input.startsWith('http')) {
    const [name, ...rest] = input.split(':');
    let url = rest.join(':').trim();
    // Add https:// if no protocol specified
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    return {
      name: name.trim(),
      url: url
    };
  }
  let url = input;
  // Add https:// if no protocol specified
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = 'https://' + url;
  }
  return {
    name: extractDomain(url),
    url: url
  };
}

function extractDomain(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname.replace('www.', '');

  } catch (e) {
    return url;
  }
}

function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}

function getFaviconUrl(websiteUrl) {
  try {
    const url = new URL(websiteUrl);
    const domain = url.hostname;
    // Use Google's favicon service or a CDN
    return `https://www.google.com/s2/favicons?domain=${domain}&sz=16`;
  } catch (e) {
    return 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22%3E%3Crect fill=%22%23ccc%22 width=%2216%22 height=%2216%22/%3E%3C/svg%3E';
  }
}

// ==================== LOAD ALL SETTINGS ====================


// ==================== VISIBILITY TOGGLES ====================
function initializeVisibilityToggles() {
  const toggles = {
    'searchBarToggle': 'searchBarContainer',
    'quickAccessToggle': 'quickAccessContainer',
    'appsMenuToggle': 'googleAppsBtn',
    'weatherWidgetToggle': 'weatherWidget',
    'calendarWidgetToggle': 'calendarWidget',
    'clockWidgetToggle': 'clockWidget'
  };

  Object.entries(toggles).forEach(([toggleId, elementId]) => {
    const toggleDiv = document.getElementById(toggleId);
    const toggleSwitch = toggleDiv.querySelector('.toggle-switch');

    toggleSwitch.addEventListener('click', function() {
      const element = document.getElementById(elementId);
      const isHidden = element.style.display === 'none';
      
      if (isHidden) {
        element.style.display = '';
        toggleSwitch.classList.add('active');
      } else {
        element.style.display = 'none';
        toggleSwitch.classList.remove('active');
      }
      
      // Save visibility state
      localStorage.setItem(`visibility_${elementId}`, isHidden ? 'visible' : 'hidden');
    });
  });
}

function restoreVisibilityToggles() {
  const elements = ['weatherWidget', 'calendarWidget', 'clockWidget', 'searchBarContainer', 'quickAccessContainer', 'googleAppsBtn'];
  
  elements.forEach(elementId => {
    const element = document.getElementById(elementId);
    const visibility = localStorage.getItem(`visibility_${elementId}`);
    const toggleId = getToggleIdForElement(elementId);
    const toggleSwitch = document.getElementById(toggleId)?.querySelector('.toggle-switch');
    
    if (visibility === 'hidden') {
      console.log('Hiding', elementId);
      element.style.display = 'none';
      if (toggleSwitch) toggleSwitch.classList.remove('active');
    } else {
      element.style.display = 'true';
      if (toggleSwitch) toggleSwitch.classList.add('active');
    }
  });
}

function getToggleIdForElement(elementId) {
  const map = {
    'searchBarContainer': 'searchBarToggle',
    'quickAccessContainer': 'quickAccessToggle',
    'googleAppsBtn': 'appsMenuToggle',
    'weatherWidget': 'weatherWidgetToggle',
    'calendarWidget': 'calendarWidgetToggle',
    'clockWidget': 'clockWidgetToggle'
  };
  return map[elementId];
}

// ==================== SETTINGS ====================
function initializeResetButton() {
  const resetBtn = document.getElementById('resetAllBtn');
  if (resetBtn) {
    resetBtn.addEventListener('click', function() {
      if (confirm('Are you sure you want to reset ALL settings? This will:\n- Clear background image\n- Remove all quick access links\n- Remove all custom apps\n- Reset visibility to defaults')) {
        resetAllSettings();
      }
    });
  }
}

function resetAllSettings() {
 localStorage.clear();
  location.reload();
}

// newtab.js - paste-ready
// Uses WeatherAPI key taken from Example.html (kept local)
const API_KEY = 'e4b5e24ec77e46a3a29212051250311'; // from Example.html (local use)

document.addEventListener('DOMContentLoaded', () => {
  initWidgets();
  initCustomizer();
  loadAllSettings();
  // set default city if none
  const savedCity = localStorage.getItem('weatherCity') || 'Stockholm';
  document.getElementById('cityInput').value = savedCity;
  fetchWeather(savedCity);
});

// ----------------- Clock -----------------
function updateClock() {
  const now = new Date();
  const timeText = now.toLocaleTimeString('sv-SE', { hour12:false });
  document.getElementById('timeText').textContent = timeText;
  document.getElementById('timeZoneText').textContent = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
}
setInterval(updateClock, 1000);
updateClock();

// ----------------- Calendar -----------------
function renderCalendar() {
  const now = new Date();
  const month = now.getMonth();
  const year = now.getFullYear();
  const firstDay = new Date(year, month, 1).getDay(); // 0=Sun
  const daysInMonth = new Date(year, month+1, 0).getDate();
  let html = '<table>';
  html += `<tr><th colspan="7">${now.toLocaleString(undefined, { month:'long' })} ${year}</th></tr>`;
  html += '<tr><th>Su</th><th>Mo</th><th>Tu</th><th>We</th><th>Th</th><th>Fr</th><th>Sa</th></tr>';
  let day = 1;
  for (let i=0;i<6;i++){
    html += '<tr>';
    for (let j=0;j<7;j++){
      if ((i===0 && j<firstDay) || day>daysInMonth) {
        html += '<td></td>';
      } else {
        const cls = day === now.getDate() ? 'today' : '';
        html += `<td class="${cls}">${day}</td>`;
        day++;
      }
    }
    html += '</tr>';
  }
  html += '</table>';
  document.getElementById('calendar').innerHTML = html;
}
renderCalendar();

// ----------------- Weather (current) -----------------
async function fetchWeather(city='Stockholm') {
  try {
    const url = `https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${encodeURIComponent(city)}&aqi=no`;
    const res = await fetch(url);
    const data = await res.json();
    if (!data || data.error) {
      showWeatherError(data?.error?.message || 'Location not found');
      return;
    }
    const icon = `https:${data.current.condition.icon}`;
    document.getElementById('weatherIcon').src = icon;
    document.getElementById('weatherTemp').textContent = `${data.current.temp_c}°C`;
    document.getElementById('weatherDesc').textContent = data.current.condition.text;
    document.getElementById('weatherLocation').textContent = `${data.location.name}, ${data.location.country}`;
    // store last city
    localStorage.setItem('weatherCity', city);
  } catch (err) {
    console.error('Weather error', err);
    showWeatherError('Network error');
  }
}
function showWeatherError(msg){
  document.getElementById('weatherIcon').src = '';
  document.getElementById('weatherTemp').textContent = '--°C';
  document.getElementById('weatherDesc').textContent = msg;
  document.getElementById('weatherLocation').textContent = '';
}

// hookup city input
document.addEventListener('click', (e) => {
  if (e.target && e.target.id === 'setCityBtn') {
    const city = document.getElementById('cityInput').value.trim();
    if (city) {
      fetchWeather(city);
      renderForecast(city);
    }
  }
});

document.addEventListener('click', (e) => {
  const changeCityBtn = e;
  if (changeCityBtn.target && changeCityBtn.target.id === 'changeCityBtn') {
     document.getElementById('weatherMenu').style.display = document.getElementById('weatherMenu').style.display === 'block' ? 'none' : 'block';
  }
 
});

// ----------------- Draggable widgets + persist positions -----------------
function makeDraggable(widget){
  widget.style.position = 'absolute';
  const saved = JSON.parse(localStorage.getItem('widgetPos') || '{}');
  const id = widget.id || (widget.id = 'w-'+Math.random().toString(36).slice(2,9));
  if (saved[id]) {
    widget.style.left = saved[id].x + 'px';
    widget.style.top = saved[id].y + 'px';
  } else {
    // keep existing flow placement if not saved
    // but ensure absolute coords (take bounding rect)
    const rect = widget.getBoundingClientRect();
    if (!widget.style.left) widget.style.left = rect.left + 'px';
    if (!widget.style.top) widget.style.top = rect.top + 'px';
  }

  let offsetX=0, offsetY=0, dragging=false;
 widget.addEventListener('mousedown', (ev) => {
  // Block dragging on interactive elements
  if (!ev.target.closest('a, button, input, textarea, select, label, i')) {
    ev.preventDefault();
    dragging = true;
    widget.style.cursor = 'grabbing';
    offsetX = ev.clientX - widget.getBoundingClientRect().left;
    offsetY = ev.clientY - widget.getBoundingClientRect().top;
    widget.style.zIndex = 200;
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  }
});


  function onMove(e){
    if (!dragging) return;
    widget.style.left = (e.clientX - offsetX) + 'px';
    widget.style.top = (e.clientY - offsetY) + 'px';
  }
  function onUp(){
    dragging = false;
    widget.style.cursor = 'grab';
    widget.style.zIndex = '';
    // save positions
    const p = JSON.parse(localStorage.getItem('widgetPos') || '{}');
    p[id] = { x: parseInt(widget.style.left,10) || 0, y: parseInt(widget.style.top,10) || 0 };
    localStorage.setItem('widgetPos', JSON.stringify(p));
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
  }
}

function initWidgets(){
  const widgets = Array.from(document.querySelectorAll('#widgetsContainer .widget'));
  widgets.forEach(w => makeDraggable(w));
}

// ----------------- Customizer: background alpha, text color, blur -----------------
function initCustomizer(){
  const btn = document.getElementById('customizerBtn');
  const panel = document.getElementById('widgetCustomizer');
  const bgRange = document.getElementById('bgAlphaRange');
  const colorPicker = document.getElementById('textColorPicker');
  const blurRange = document.getElementById('widgetBlurRange');
  const saveBtn = document.getElementById('saveCustomizerBtn');
  const resetBtn = document.getElementById('resetCustomizerBtn');

  // load saved values to inputs
  const savedAlpha = localStorage.getItem('widgetBgAlpha');
  const savedColor = localStorage.getItem('widgetTextColor');
  const savedBlur = localStorage.getItem('widgetBlurPx');

  if (savedAlpha) bgRange.value = savedAlpha;
  if (savedColor) colorPicker.value = savedColor;
  if (savedBlur) blurRange.value = savedBlur;

  // apply immediately
  applyCustomizerValues(bgRange.value, colorPicker.value, blurRange.value);

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    panel.style.display = panel.style.display === 'block' ? 'none' : 'block';
  });

  // close when clicking outside
  

  // live update preview when changing controls
  [bgRange, colorPicker, blurRange].forEach(input => {
    input.addEventListener('input', () => {
      applyCustomizerValues(bgRange.value, colorPicker.value, blurRange.value);
    });
  });

  saveBtn.addEventListener('click', () => {
    localStorage.setItem('widgetBgAlpha', bgRange.value);
    localStorage.setItem('widgetTextColor', colorPicker.value);
    localStorage.setItem('widgetBlurPx', blurRange.value);
    panel.style.display = 'none';
  });

  resetBtn.addEventListener('click', () => {
    localStorage.removeItem('widgetBgAlpha');
    localStorage.removeItem('widgetTextColor');
    localStorage.removeItem('widgetBlurPx');
    localStorage.removeItem('weatherWidgetVisible');
    localStorage.removeItem('calendarWidgetVisible');
    localStorage.removeItem('clockWidgetVisible');
    localStorage.removeItem('widgetPos');
    // defaults
    bgRange.value = 35;
    colorPicker.value = '#ffffff';
    blurRange.value = 8;
    applyCustomizerValues(35, '#ffffff', 8);

  });
}

function applyCustomizerValues(alphaValue, textColor, blurPx){
  // alphaValue is 0-100 => convert to 0-1
  const alpha = Math.max(0, Math.min(100, parseInt(alphaValue,10))) / 100;
  // set CSS variables
  document.documentElement.style.setProperty('--widget-bg', `rgba(30,30,30,${alpha})`);
  document.documentElement.style.setProperty('--widget-border', `rgba(255,255,255,${Math.max(0.06, alpha*0.5)})`);
  document.documentElement.style.setProperty('--text-color', textColor || '#ffffff');
  // set blur style on widgets
  const widgets = document.querySelectorAll('.widget');
  widgets.forEach(w => {
    w.style.backdropFilter = `blur(${blurPx}px) saturate(160%)`;
    w.style.webkitBackdropFilter = `blur(${blurPx}px) saturate(160%)`;
  });
}

// ----------------- Top-right apps toggle (small helper) -----------------





// ----------------- load/save settings -----------------
function loadAllSettings(){
  // widget positions already restored in makeDraggable initial call
  // load customizer values
  const alpha = localStorage.getItem('widgetBgAlpha');
  const textColor = localStorage.getItem('widgetTextColor');
  const blur = localStorage.getItem('widgetBlurPx');
  applyCustomizerValues(alpha !== null ? alpha : 35, textColor || '#ffffff', blur !== null ? blur : 8);

  // restore visibility of search/quick access if used from original script
  // (your existing restoreVisibilityToggles code may be combined if you want)
   localStorage.getItem('weatherCity') && fetchWeather(localStorage.getItem('weatherCity'));

  // re-render calendar (in case saved month changed)
  renderCalendar();
      document.getElementById('calendarWidget').style.display = localStorage.getItem('visibility_calendarWidget') === 'visible' ? 'block' : 'none';
  document.getElementById('weatherWidget').style.display = localStorage.getItem('visibility_weatherWidget') === 'visible' ? 'block' : 'none';
  
document.getElementById('clockWidget').style.display = localStorage.getItem('visibility_clockWidget') === 'visible' ? 'block' : 'none';

document.getElementById('weatherWidgetToggle').querySelector('.toggle-switch').classList.toggle('active', localStorage.getItem('visibility_weatherWidget') === 'visible');
document.getElementById('clockWidgetToggle').querySelector('.toggle-switch').classList.toggle('active', localStorage.getItem('visibility_clockWidget') === 'visible');
document.getElementById('calendarWidgetToggle').querySelector('.toggle-switch').classList.toggle('active', localStorage.getItem('visibility_calendarWidget') === 'visible');


  
}

// Expose a simple API to change background/transparency/textcolor programmatically if desired
window.NewTabCustomizer = {
  setBackgroundAlpha: (n) => { localStorage.setItem('widgetBgAlpha', String(n)); applyCustomizerValues(n, localStorage.getItem('widgetTextColor')||'#fff', localStorage.getItem('widgetBlurPx')||8); },
  setTextColor: (hex) => { localStorage.setItem('widgetTextColor', hex); applyCustomizerValues(localStorage.getItem('widgetBgAlpha')||35, hex, localStorage.getItem('widgetBlurPx')||8); }
};

// ----------------- small helpers -----------------
function safeGet(id){ return document.getElementById(id); }

// Quick fallback: if any widget had inline positioning destroyed by CSS, ensure they can be grabbed
document.addEventListener('DOMContentLoaded', () => {
  Array.from(document.querySelectorAll('#widgetsContainer .widget')).forEach(w => {
    // ensure at least minimal left/top values so dragging works
    if (!w.style.left) w.style.left = w.getBoundingClientRect().left + 'px';
    if (!w.style.top) w.style.top = w.getBoundingClientRect().top + 'px';
  });
});
