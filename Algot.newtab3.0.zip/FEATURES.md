# Newtab 2.0 - New Features

## Overview
The newtab.html file has been updated with a complete settings system and quick access links feature. The upload button has been replaced with a settings menu that controls all customization options.

---

## 🎯 Key Features

### 1. **Settings Menu** (Replaces Upload Button)
- **Button**: Bottom left corner (gear icon ⚙️)
- **Opens**: A comprehensive settings panel with three sections
- **Features**: All settings are automatically saved to localStorage

### 2. **Background Settings**
- Upload image files directly
- Paste image URLs
- Automatic image validation
- Suggested free image sources (Pixabay, Unsplash)

### 3. **Quick Access Links** 
- **Display**: Below the search bar, always visible
- **Add Links**: Through settings menu
- **Auto Favicons**: Website favicons automatically fetched from each site
- **Fallback**: Gray placeholder if favicon unavailable
- **Plus Button**: Quick "Add Link" button in the display area

### 4. **Custom Apps in Menu**
- Add custom links to the top-right apps menu (grid icon)
- Quick access to your favorite websites
- Auto-generated favicons for each app
- Remove apps from settings

---

## 📝 How to Use

### Adding Quick Access Links
1. Click the **Settings button** (⚙️) at bottom left
2. Go to **"Quick Access Links"** section
3. Enter a link in one of these formats:
   - `https://example.com` (auto-names from domain)
   - `GitHub:https://github.com` (custom name before colon)
4. Click **"Add Link"**
5. Link appears immediately below search bar with auto-fetched favicon

### Adding Custom Apps to Menu
1. Click the **Settings button** (⚙️) at bottom left
2. Go to **"Custom Apps"** section
3. Enter a link in same format as quick access links
4. Click **"Add App"**
5. App appears in the top-right menu with auto-fetched favicon

### Managing Links
- Each added link appears in the settings menu
- Click **"Remove"** to delete any link
- Changes save automatically

---

## 🎨 Icon Behavior

### Favicon Fetching
- Uses Google's favicon service: `www.google.com/s2/favicons?domain=...`
- Automatically extracts domain from any URL
- Shows gray placeholder if favicon cannot be loaded
- Works with all websites

### Custom Names
You can specify custom display names:
- Format: `CustomName:https://example.com`
- If not specified, domain name is used automatically
- Example: `Gmail:https://mail.google.com`

---

## 💾 Data Storage

All settings are stored in browser's **localStorage**:
- `backgroundImage`: Background image URL or data
- `quickAccessLinks`: Array of quick access link objects
- `customApps`: Array of custom app objects

**Note**: These persist across browser sessions and are local to your browser.

---

## 🔗 Input Formats

### Valid URL formats:
- `https://example.com`
- `http://example.com`
- `https://subdomain.example.com`
- With custom name: `Name:https://example.com`

### Domain extraction:
- `https://www.google.com` → "google"
- `https://mail.example.com` → "mail.example"
- Custom name always overrides auto-detection

---

## 📱 Responsive Design

- Quick access links wrap responsively below search bar
- Settings menu scrollable if many items added
- All buttons work on touch devices
- Glassmorphism design maintained throughout

---

## 🚀 Examples

### Quick Access Link
Input: `Notion:https://www.notion.so`
Result: Appears below search bar with Notion favicon + "Notion" text

### Custom App
Input: `https://discord.com`
Result: Added to top-right menu with Discord favicon + "discord" text

---

## ✨ Technical Details

- **Framework**: Vanilla JavaScript (no dependencies)
- **Storage**: Browser localStorage
- **Favicon Service**: Google's free favicon CDN
- **Design**: Glassmorphism with backdrop blur
- **Compatibility**: All modern browsers
