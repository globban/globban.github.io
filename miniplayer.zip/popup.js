const modeSelect = document.getElementById("modeSelect");
const launchBtn = document.getElementById("launchBtn");

// Load saved mode
chrome.storage.sync.get("mode", (data) => {
  if (data.mode) modeSelect.value = data.mode;
});

// Save selected mode whenever changed
modeSelect.addEventListener("change", () => {
  chrome.storage.sync.set({ mode: modeSelect.value });
});

// Launch Bit888
launchBtn.onclick = () => {
  chrome.storage.sync.get("mode", (data) => {
    const mode = data.mode || "inject_page";

    if (mode === "popup_window") {
      chrome.windows.create({
        url: "https://globban.github.io/gameswipe.html",
        type: "popup",
        width: 500,
        height: 400
      });
    } else if (mode === "inject_page") {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          files: ["inject.js"]
        });
        chrome.scripting.insertCSS({
          target: { tabId: tabs[0].id },
          files: ["inject.css"]
        });
      });
    }
  });
};
