if (!document.getElementById("bit888_window")) {
  const container = document.createElement("div");
  container.id = "bit888_window";
  container.innerHTML = `
    <div id="bit888_topbar">Games</div>
    <iframe src="https://globban.github.io/gameswipe.html"></iframe>
  `;
  document.body.appendChild(container);

  const win = container;
  const topbar = document.getElementById("bit888_topbar");

  // Dragging
  let dragging = false, offsetX = 0, offsetY = 0;
  topbar.addEventListener("mousedown", (e) => {
    dragging = true;
    offsetX = e.clientX - win.offsetLeft;
    offsetY = e.clientY - win.offsetTop;
  });
  document.addEventListener("mousemove", (e) => {
    if (dragging) {
      win.style.left = (e.clientX - offsetX) + "px";
      win.style.top = (e.clientY - offsetY) + "px";
    }
  });
  document.addEventListener("mouseup", () => dragging = false);

  // Close on click outside
  document.addEventListener("mousedown", (e) => {
    if (!win.contains(e.target)) {
      win.remove();
    }
  });
}
