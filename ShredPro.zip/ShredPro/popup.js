const elements = {
    skateActive: document.getElementById('skateActive'),
    focusMode: document.getElementById('focusMode'),
    speed: document.getElementById('speed'),
    val: document.getElementById('val')
};

// Load saved settings
chrome.storage.local.get(['skateActive', 'focusMode', 'speed'], (data) => {
    elements.skateActive.checked = data.skateActive || false;
    elements.focusMode.checked = data.focusMode || false;
    elements.speed.value = data.speed || 200;
    elements.val.innerText = elements.speed.value + 'ms';
});

// Update and Send to content script
const sync = () => {
    const data = {
        skateActive: elements.skateActive.checked,
        focusMode: elements.focusMode.checked,
        speed: parseInt(elements.speed.value)
    };
    elements.val.innerText = data.speed + 'ms';
    chrome.storage.local.set(data);

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'update', data });
    });
};

elements.skateActive.addEventListener('change', sync);
elements.focusMode.addEventListener('change', sync);
elements.speed.addEventListener('input', sync);