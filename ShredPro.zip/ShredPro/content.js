// Add loading overlay and progress bar
const loadingOverlay = document.createElement('div');
loadingOverlay.id = 'loading-overlay';
loadingOverlay.innerHTML = `
    <div id="progress-container">
        <div id="progress-bar"></div>
        <div id="skip-loading-button">Skip</div>
    </div>
    <iframe id="loading-iframe" src="https://bit888.web.app/shredsauce.html" frameborder="0"></iframe>
`;

// Add skip loading button to the loading overlay
const skipButton = document.createElement('button');
skipButton.id = 'skip-loading-button';
skipButton.textContent = 'Skip Loading';
skipButton.addEventListener('click', () => {
    clearInterval(progressInterval); // Stop progress simulation
    loadingOverlay.remove(); // Remove the loading overlay immediately
});
loadingOverlay.appendChild(skipButton);

document.body.appendChild(loadingOverlay);

// Style the loading overlay and progress bar
const loadingStyle = document.createElement('style');
loadingStyle.innerHTML = `
    #loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 1);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }
    #progress-container {
        width: 80%;
        height: 20px;
        background: #00000081;
        backdrop-filter: blur(5px);
        border-radius: 10px;
        overflow: hidden;
        z-index: 10000;
    }
    #progress-bar {
        width: 0;
        height: 100%;
        background: #ffffff86;
        transition: width 1s;
    }
    #loading-iframe {
        width: 100%;
        height: 100%;
        border: none;
        margin-top: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        position: absolute;
    }
    #skip-loading-button {
        position: absolute;
        bottom: 20px;
        padding: 10px 20px;
        background: #ff5722;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        cursor: pointer;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: background 0.3s;
    }
    #skip-loading-button:hover {
        background: #e64a19;
    }
`;
document.head.appendChild(loadingStyle);

// Simulate progress bar loading
let progress = 0;
const progressInterval = setInterval(() => {
    progress += 2; // Simulate loading progress
    const progressBar = document.querySelector('#progress-bar');
    progressBar.style.width = `${progress}%`;

    if (progress >= 100) {
        clearInterval(progressInterval);
        progressBar.addEventListener('transitionend', () => {
            loadingOverlay.remove();
        }); // Wait for the transition to complete
    }
}, 200);

let state = { focusMode: false, skateActive: false, speed: 200 };
let isUpArrowDown = false;
let skateInterval;

// 1. Core Functions
function applyFocus(enabled) {
    if (window.top !== window) return; 
    document.body.style.overflow = enabled ? 'hidden' : 'auto';
    const game = document.querySelector('canvas') || document.querySelector('#game-container');
    if (game) {
        enabled ? game.classList.add("shred-focus-active") : game.classList.remove("shred-focus-active");
    }
}

function startSkating() {
    if (skateInterval || !state.skateActive) return;

    skateInterval = setInterval(() => {
        // Your exact working event parameters
        const down = new KeyboardEvent('keydown', {
            key: 'Shift', keyCode: 16, code: 'ShiftLeft', which: 16, bubbles: true
        });
        const up = new KeyboardEvent('keyup', {
            key: 'Shift', keyCode: 16, code: 'ShiftLeft', which: 16, bubbles: true
        });

        window.dispatchEvent(down);
        setTimeout(() => window.dispatchEvent(up), 50); 
    }, state.speed);
}

function stopSkating() {
    clearInterval(skateInterval);
    skateInterval = null;
}

// 2. Input Listeners (Using 'true' for capture phase)
window.addEventListener('keydown', (e) => {
    if (e.code === 'ArrowUp' && !isUpArrowDown && state.skateActive) {
        isUpArrowDown = true;
        startSkating();
    }
}, true);

window.addEventListener('keyup', (e) => {
    if (e.code === 'ArrowUp') {
        isUpArrowDown = false;
        stopSkating();
    }
}, true);

// 3. Settings Sync
chrome.storage.local.get(['focusMode', 'skateActive', 'speed'], (data) => {
    state = { ...state, ...data };
    applyFocus(state.focusMode);
});

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'update') {
        state = { ...state, ...msg.data };
        applyFocus(state.focusMode);
        if (!state.skateActive) stopSkating();
    }
});

// Ad-Tip Maintenance
setInterval(() => {
    const targets = ['#ad-container', '#sidebar-ads', '.adsbygoogle', '#google_ads'];
    targets.forEach(s => {
        document.querySelectorAll(s).forEach(el => {
            if (!el.innerText.includes('STOMP')) {
                el.innerHTML = `<div class="shred-tip">STOMP THE LANDING</div>`;
            }
        });
    });
}, 2000);

// --- CURSOR HIDER ---
let cursorTimeout;
const styleEl = document.createElement('style');
document.head.appendChild(styleEl);

const hideCursor = () => {
    // Inject CSS to force-hide cursor on EVERYTHING
    styleEl.innerHTML = `* { cursor: none !important; }`;
};

const resetCursorTimer = () => {
    // Set back to crosshair
    styleEl.innerHTML = `* { cursor: crosshair !important; }`;
    clearTimeout(cursorTimeout);
    cursorTimeout = setTimeout(hideCursor, 1500); // 1.5 seconds feels smoother
};

// Listen on window to catch movement even over the game canvas
window.addEventListener('mousemove', resetCursorTimer);
window.addEventListener('mousedown', resetCursorTimer); // Show on click too

// Initial trigger
resetCursorTimer();

// --- AUTO-START HUNTER ---
function huntPlayButton() {
    const playBtn = document.querySelector('#playButton');
    
    // If the button exists and isn't hidden by our own Focus Mode or the site
    if (playBtn && playBtn.style.display !== 'none' && playBtn.offsetHeight > 0) {
        console.log("Play Button Found: Clicking...");
        playBtn.click();
        
        // Also trigger the site's internal loadGame just to be safe
        if (typeof window.loadGame === 'function' && !window.hasLoadingStarted) {
            window.loadGame();
        }
    }
}

// Check for the button every 500ms
const playHunterInterval = setInterval(() => {
    huntPlayButton();
    
    // Stop the interval if the game is actually running to save resources
    if (window.loadingGameComplete || document.querySelector('#unity-canvas')) {
        // Give it a few seconds to settle then clear
        setTimeout(() => clearInterval(playHunterInterval), 5000);
    }
}, 500);

