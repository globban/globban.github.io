chrome.action.onClicked.addListener(() => {
  chrome.windows.create({
    url: "https://shredsauce.com",
    type: "popup",
    width: 1024,
    height: 768
  });
});