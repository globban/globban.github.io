chrome.runtime.onMessage.addListener(msg => {
    if (msg.target === 'offscreen' && msg.action === "play") {
        const audio = new Audio(msg.url);
        audio.play().catch(e => console.error("Playback failed", e));
    }
});