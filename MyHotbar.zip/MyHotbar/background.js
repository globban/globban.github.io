chrome.commands.onCommand.addListener(async (command) => {
    const slot = command.split('-')[1];
    const data = await chrome.storage.local.get(`sound_${slot}`);
    const url = data[`sound_${slot}`];

    if (url) {
        if (!(await chrome.offscreen.hasDocument?.())) {
            await chrome.offscreen.createDocument({
                url: 'offscreen.html', reasons: ['AUDIO_PLAYBACK'], justification: 'play sound'
            });
        }
        chrome.runtime.sendMessage({ action: "play", url: url, target: 'offscreen' });
    }
});