const slotsDiv = document.getElementById('slots');
const clearBtn = document.getElementById('clear');

function updateUI() {
    slotsDiv.innerHTML = '';
    chrome.storage.local.get(null, (data) => {
        for (let i = 1; i <= 4; i++) {
            const url = data[`sound_${i}`];
            const div = document.createElement('div');
            div.className = 'slot';
            div.innerHTML = `
                <b>#${i}</b>
                <span>${url ? 'Linked' : 'Empty'}</span>
                ${url ? `<button class="play-btn" data-url="${url}">▶</button>` : ''}
            `;
            slotsDiv.appendChild(div);
        }
        document.querySelectorAll('.play-btn').forEach(b => {
            b.onclick = () => new Audio(b.dataset.url).play();
        });
    });
}

clearBtn.onclick = () => {
    chrome.storage.local.clear();
    updateUI();
};

updateUI();