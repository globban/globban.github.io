function inject() {
    document.querySelectorAll('.instant').forEach(item => {
        if (item.querySelector('.hotbar-btn')) return;
        const btn = document.createElement('button');
        btn.innerText = "HOTBAR";
        btn.className = "hotbar-btn";
        btn.setAttribute('style', 'background:#0fcc; color:#000; border:none; border-radius:4px; font-weight:bold; cursor:pointer; padding:4px; margin-top:5px; width:100%;');
        
        btn.onclick = (e) => {
            e.stopPropagation();
            const raw = item.querySelector('.small-button').getAttribute('onclick');
            const url = "https://www.myinstants.com" + raw.match(/'([^']+)'/)[1];
            const slot = prompt("Bind to Hotbar Slot (1-4):");
            if (slot >= 1 && slot <= 4) {
                chrome.storage.local.set({ [`sound_${slot}`]: url });
                alert("Bound to Slot " + slot);
            }
        };
        item.appendChild(btn);
    });
}
setInterval(inject, 1000);